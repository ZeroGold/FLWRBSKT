import React, {useState} from 'react'

const Products = ({}) => {
    return (
        <h1>Products</h1>
    )
}
export default Products