import React, {useState} from 'react'
import { AppBar, Box, Toolbar, Typography, Button, IconButton, MenuIcon } from '@mui/material';

const Menu = ({}) => {
    return (
        <h1>menu</h1>
    )
}
export default Menu;